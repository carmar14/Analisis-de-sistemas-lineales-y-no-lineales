clear 
close all
clc
%primer sistema
A1=[-5];
B1=[1];
C1=[2];
num1=2;
den1=[1 5];
%segundo sistema
A2=[0 1; -30 -12];
B2=[0;1];
C2=[20 0];
num2=20;
den2=[1 12 30];
%tercer sistema
A3=[0 1 0; 0 0 1; -52 -29 -8];
B3=[0; 0; 1];
C3=[26 0 0];
num3=26;
den3=[1 8 29 52];
