%%
close all
K=1;
tao=1;
ftpo=tf(K,[tao 1]);
figure;
step(ftpo);
figure
pzmap(ftpo);
axis([-5 1 -2 2]);
grid on
%%
K=1;
tao=2;
ftpo2=tf(K,[tao 1]);
figure;
step(ftpo2);
figure
pzmap(ftpo2);
axis([-5 1 -2 2]);
grid on