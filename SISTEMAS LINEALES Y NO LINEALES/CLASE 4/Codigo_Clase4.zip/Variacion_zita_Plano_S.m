close all
k=1;
wn=2;
figure
hold on
for zita=0:0.1:1
  ftc=tf(k*wn^2,[1,2*zita*wn,wn^2])
  %step(ftc);
  pzmap(ftc)
  grid
  axis([-5,1,-2,2])
 % axis([-5,1,-2,2])
end
hold off
