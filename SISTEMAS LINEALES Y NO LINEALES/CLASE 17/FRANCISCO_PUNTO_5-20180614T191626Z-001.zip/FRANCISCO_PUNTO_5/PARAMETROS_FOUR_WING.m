clear all
close all
clc
a=0.2;
b=-0.01;
c=1;
d=-0.4;
e=-1.0;
f=-1.0;